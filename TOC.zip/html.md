[Directory - Listing Templates](https://pixelaar.com/) | [Documentation
table of contents](TOC.md)

##HTML Structure
This template use bootstrap framework.For more info please visit this page

             <section class="add-directory-list ptb-100">
                                <div class="add-directory-list-wrap">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-8 col-md-offset-2">
                                                <div class="add-directory-list-content text-center white-text">
                                                    <h2 class="white-text">Post Your Service On Listing Master</h2>
                                                    <p>Phosfluorescently pontificate multimedia based paradigms via premier schemas.
                                                        Energistically conceptualize high-quality outsourcing and interdependent
                                                        e-services.</p>
                                                    <div class="add-listing-btn mt-30">
                                                        <a href="#" class="pxlr-solid-btn"><i class="fa fa-plus"></i> Add
                                                            Listing</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
   

### blog.html
Having a lot of content means a lot of scrolling. It helps to make things 
a little easier for your readers if you include an easy way to jump all 
the way back to the top of the page. Adding a Back To Top button can easily
solve scrolling issues and is really simple to implement! I’ve included a really
easy Back To Top button here for you that you can add to any website or blog.
All you need to edit are the theme’s CSS file and the main HTML template file


### blog-details.html

This file contains all settings regarding custom tiles for IE11 and Edge.

For more info on this topic, please refer to

### 404.html

A helpful custom 404 to get you started.

### contact.html

This is the default HTML  contact form is basically a set of questions filled out 
on the webpage by your visitor that is automatically sent to your email when it is
filled out HTML with your setup.

### index.html

Edit this file to include the team that worked on your website and edit code.

### list-details.html

List-details View is a view Overview that displays a list and Video  of scrollable items. The 
list items  Review are automatically inserted to the list using an Adapter that
pulls content from.

### list-list-view.html

List View is a view group that displays a list of scrollable items.

### list-list-view-half.html
ListView is a view two item that displays a list of scrollable items. 