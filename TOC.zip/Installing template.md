[Directory - Listing Templates](https://pixelaar.com/) | [Documentation
table of contents](TOC.md)

##Installing Template

After unzip the download pack, you'll found a Template Folder with all the files.

You can view this Template in any browser, you can display or edit the Template without an internet connection.

The three sections that will not work is the Google map Section which contains external link to get the map source.

the Contact form which uses PHP, so will work only online.

Now open your FTP Client (like Filezilla) or directly through cpanel, upload the content of the Template on your server root.

Once the files are done uploading go to www.yourdomainname.com/index.html

Please follow the tutorial to have a simple installation of the theme. 