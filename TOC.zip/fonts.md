# font.md

Information about the default JavaScript included in the project.


**Font Awesome**

Font Awesome gives you scalable vector icons that can instantly be 
customized — size, color, drop shadow, and anything that can be done 
with the power of CSS Font face or font family is the typeface that
will be applied by a web browser to some text. The font is relevant 
for the display of text on the screen, on a printer or another device.


    <div class="item">
       <div class="hospitality-single text-center">
          <span>
            <i class="fa fa-trophy"></i>
          </span>
              <h6>Great View</h6>
                <p>Rapidiously optimize multidisciplinary vortals via turnkey practices.</p>
       </div>                                            
    </div>
    


  
