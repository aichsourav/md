[Directory - Listing Templates](https://pixelaar.com/) | [Documentation
table of contents](TOC.md)

##CSS
I am using one primary CSS file for this template: /css/style.css. This file contains all style information for the theme.

Use one of the included child themes as a base for further CSS customization.

Styles are being used and test-edit the CSS.
   
   ink rel="stylesheet" href="css/font-awesome.min.css">
   
       <!-- magnific popup css-->
       <link rel="stylesheet" href="css/magnific-popup.css">
   
       <!-- animate css -->
       <link href="css/animate.min.css" rel="stylesheet">
   
   
       <!--owl carousel -->
       <link href="owlcarousel/assets/owl.theme.default.min.css" rel="stylesheet">
       <link href="owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
   
       <!--custom scroll bar css-->
       <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
   
       <!-- bootstrap core css -->
       <link href="css/bootstrap.min.css" rel="stylesheet">
   
       <!-- custom css -->
       <link href="css/style.css" rel="stylesheet">
   
       <!-- responsive css -->
       <link href="css/responsive.css" rel="stylesheet">